

package ukmmvc;
import ukmmvc.view.FormMahasiswa;
/**
 *
 * @author Firman Wisambudi
 */
public class ukmMVC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new FormMahasiswa().setVisible(true);
    }
    
}
