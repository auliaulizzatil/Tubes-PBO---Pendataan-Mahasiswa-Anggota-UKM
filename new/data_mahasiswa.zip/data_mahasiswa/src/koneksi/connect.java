/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;
import com.mysqljdbc.Driver;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author adam rahman
 */
public class connect {
    static Connection koneksi;
    public static Connection getConnection(){
        try {
              String url, user, password;
                url = "jdbc:mysql://localhost:3306/dt_mahasiswa"; //alamat DB
                user = "root";
                password = "";
                koneksi = DriverManager.getConnection(url, user, password);
          
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "koneksi database gagal");
        }
        return koneksi;
    }
}
